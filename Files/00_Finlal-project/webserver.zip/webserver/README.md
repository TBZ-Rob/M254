# Restaurant – Camunda Webinterface

Lokales Webinterface + Backend für den Kunde-Prozess (`Process_0t4z7yo`).
Das Backend spricht per REST mit Camunda 8 Run, arbeitet die Service Tasks als
Job Worker ab und simuliert Kellner & Küche durch Publizieren der Nachrichten.

## Voraussetzungen
- **Node.js 18+** (für globales `fetch`)
- **Camunda 8 Run läuft** (Operate unter http://localhost:8080/operate erreichbar)
- Das **BPMN ist deployed** (aktuelle Version im Modeler deployen)

## Start
```powershell
cd restaurant-app
npm install
npm start
```
Dann im Browser: **http://localhost:3000**

Beim Start prüft das Backend zuerst die Verbindung und gibt im Terminal aus:
```
✓ Verbindung zu Camunda ok (http://localhost:8080/v2), Broker: 1
✓ 11 Job Worker gestartet
✓ Webinterface: http://localhost:3000
```

## Ablauf testen
1. „Neue Bestellung starten" → Prozessinstanz wird erzeugt.
2. Die Service Tasks laufen automatisch; Kellner/Küche-Nachrichten werden publiziert.
3. Sobald eine Eingabe nötig ist (Getränk, Essen, Dessert, Zahlung, Trinkgeld),
   erscheint oben das passende Formular.
4. Parallel in **Operate** sichtbar, wie der Token durch den Prozess wandert.

## Variablen
- `bestellId` – Correlation-Key (automatisch gesetzt)
- `getraenk`, `hauptgericht`, `vorspeiseGewuenscht`, `dessertGewuenscht`,
  `zahlungsart`, `trinkgeldProzent` – aus den Formularen

## Hinweis
Die REST-Feldnamen (z. B. `jobKey`, `userTaskKey`, `processInstanceKey`) sind nach
der Camunda-8.9-Doku gesetzt. Falls beim ersten Lauf eine Fehlermeldung im Terminal
auftaucht, zeigt sie genau, welcher Aufruf hakt – damit lässt sich das schnell fixen.
