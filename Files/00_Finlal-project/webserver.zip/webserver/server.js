// ============================================================================
// Restaurant-Prozess: lokales Backend + Webinterface
// Spricht per REST (v2) mit Camunda 8 Run auf http://localhost:8080/v2
// - Job Worker fuer die 11 Service Tasks (Kunde-Prozess)
// - simuliert Kellner & Kueche durch Publizieren der 7 Nachrichten
// - schliesst die 5 User Tasks mit den Werten aus dem Webinterface ab
// Benoetigt Node.js 18+ (globales fetch)
// ============================================================================

import express from "express";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BASE = process.env.CAMUNDA_REST_ADDRESS || "http://localhost:8080/v2";
const PORT = process.env.PORT || 3000;
const PROCESS_ID = "Process_0t4z7yo"; // Kunde-Prozess (ausfuehrbar)
const MSG_TTL = 300000;               // Nachrichten 5 Min. puffern (in ms)

// Feste Preisliste (CHF)
const PRICES = {
  getraenke: { Wasser: 3.5, Cola: 4.5, Bier: 6.5, Wein: 8.0, Kaffee: 4.0 },
  vorspeisen: { Tagessuppe: 9.5, Blattsalat: 8.5, Bruschetta: 10.5 },
  hauptgerichte: { Pizza: 18.5, Pasta: 17.0, Schnitzel: 24.5, Salat: 14.5 },
  desserts: { Tiramisu: 8.5, Glace: 6.5, Schoggimousse: 7.5 },
};
const round2 = (x) => Math.round(x * 100) / 100;

// ---------------------------------------------------------------------------
// kleiner REST-Helfer
// ---------------------------------------------------------------------------
async function api(pathname, body, method = "POST") {
  const res = await fetch(BASE + pathname, {
    method,
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = text; }
  if (!res.ok) throw new Error(`${method} ${pathname} -> HTTP ${res.status}: ${text}`);
  return data;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------
// In-Memory-Status pro Prozessinstanz (fuer die Live-Anzeige im Frontend)
// ---------------------------------------------------------------------------
const instances = {}; // processInstanceKey -> { bestellId, steps:[], done:false }
function logStep(piKey, text) {
  const inst = instances[piKey];
  if (!inst) return;
  inst.steps.push({ t: new Date().toLocaleTimeString("de-CH"), text });
  console.log(`[${piKey}] ${text}`);
}

// ---------------------------------------------------------------------------
// Kellner-Aktionen: frueher wurden diese 7 Nachrichten automatisch publiziert,
// jetzt werden sie erst "bereit" (ready) und der Kellner loest sie manuell im
// Webinterface aus (POST /api/kellner/action).
// ---------------------------------------------------------------------------
const KELLNER_ACTIONS = {
  personenFrage:        { label: "Nach Personenzahl fragen", message: "KellnerFragtPersonenzahl" },
  tisch:               { label: "Tisch zuweisen",        message: "TischZugewiesen" },
  getraenkFrage:        { label: "Nach Getränk fragen",   message: "KellnerFragtGetraenk" },
  bestellungAufnehmen:  { label: "Bestellung aufnehmen",  message: "KellnerNimmtBestellungAuf" },
  vorspeiseServieren:   { label: "Vorspeise servieren",   message: "VorspeiseServiert" },
  hauptgangServieren:   { label: "Hauptgang servieren",   message: "HauptgangServiert" },
  dessertServieren:     { label: "Dessert servieren",     message: "DessertServiert" },
  rechnungBringen:      { label: "Rechnung bringen",      message: "RechnungGebracht" },
};
function freshKellnerState() {
  const s = {};
  for (const key of Object.keys(KELLNER_ACTIONS)) s[key] = { ready: false, done: false, applicable: true };
  s.personenFrage.ready = true; // als allererstes kann der Kellner nach der Personenzahl fragen
  s.vorspeiseServieren.applicable = false; // erst bekannt, sobald Hauptgang-Bestellung vorliegt
  s.dessertServieren.applicable = false;
  return s;
}

// lesbare Namen fuer das Log
const STEP_LABEL = {
  "restaurant-betreten": "Restaurant betreten",
  "platz-nehmen": "Am Tisch Platz genommen",
  "bestellung-aufgeben": "Bestellung aufgegeben",
  "vorspeise-essen": "Vorspeise gegessen",
  "hauptgang-essen": "Hauptgang gegessen",
  "dessert-essen": "Dessert gegessen",
  "rechnung-verlangen": "Rechnung verlangt",
  "bar-bezahlen": "Bar bezahlt",
  "karte-bezahlen": "Mit Karte bezahlt",
  "trinkgeld-geben": "Trinkgeld gegeben",
  "restaurant-verlassen": "Restaurant verlassen",
};

async function publishMessage(name, correlationKey) {
  await api("/messages/publication", {
    name,
    correlationKey,
    timeToLive: MSG_TTL,
    variables: {},
  });
  console.log(`   -> Nachricht publiziert: ${name} (key=${correlationKey})`);
}

// ---------------------------------------------------------------------------
// Job Worker: aktiviert per Long-Poll Jobs eines Typs und schliesst sie ab
// ---------------------------------------------------------------------------
async function startWorker(type) {
  while (true) {
    try {
      const r = await api("/jobs/activation", {
        type,
        worker: "restaurant-demo",
        timeout: 120000,
        maxJobsToActivate: 10,
        requestTimeout: 4000,
      });
      const jobs = r.jobs || [];
      for (const job of jobs) {
        const jobKey = job.jobKey || job.key;
        const piKey = String(job.processInstanceKey);
        const vars = job.variables || {};
        const bestellId = vars.bestellId;

        await sleep(600); // kleine Verzoegerung fuer realistischen Ablauf
        await api(`/jobs/${jobKey}/completion`, { variables: {} });
        logStep(piKey, STEP_LABEL[type] || type);

        const inst = instances[piKey];
        if (inst) {
          if (type === "restaurant-betreten") inst.kellner.tisch.ready = true;
          if (type === "platz-nehmen") inst.kellner.getraenkFrage.ready = true;
          if (type === "bestellung-aufgeben") {
            const liste = inst.essenListe.length ? inst.essenListe : [{ hauptgericht: vars.hauptgericht, vorspeise: vars.vorspeiseGewuenscht ? vars.vorspeise : null }];
            const hauptgaenge = liste.map((e) => e.hauptgericht).filter(Boolean).join(", ");
            const vorspeisen = liste.map((e) => e.vorspeise).filter(Boolean).join(", ");
            inst.koch.essen = {
              tischNr: inst.tischNr,
              hauptgericht: hauptgaenge,
              vorspeise: vorspeisen || null,
              fertig: false,
            };
            inst.kellner.vorspeiseServieren.applicable = !!vorspeisen;
            logStep(piKey, "Küchenticket erstellt 🧾");
          }
          if (type === "rechnung-verlangen") inst.kellner.rechnungBringen.ready = true;
        }
        if (type === "restaurant-verlassen" && instances[piKey]) {
          instances[piKey].done = true;
          logStep(piKey, "Besuch abgeschlossen ✓");
        }
      }
    } catch (err) {
      // bei Verbindungsproblemen kurz warten, dann erneut versuchen
      console.error(`Worker ${type}: ${err.message}`);
      await sleep(2000);
    }
  }
}

const SERVICE_TYPES = Object.keys(STEP_LABEL);

// ---------------------------------------------------------------------------
// User Tasks: Definition fuer das Frontend (Label + Formular-Art)
// ---------------------------------------------------------------------------
const USERTASKS = {
  Activity_personenzahl: { label: "Personenzahl angeben", kind: "personenzahl" }, // personen
  Activity_05poycg: {
    label: "Getränk auswählen",
    kind: "select",
    field: "getraenk",
    options: ["Wasser", "Cola", "Bier", "Wein", "Kaffee"],
  },
  Activity_0oa5gn3: { label: "Essen auswählen", kind: "essen" }, // hauptgericht + vorspeiseGewuenscht
  Act_k_dessert_wahl: { label: "Dessert?", kind: "dessert" },     // dessertGewuenscht (+ dessert)
  Act_k_zahlart: { label: "Zahlungsart", kind: "zahlung" },       // zahlungsart
  Act_k_tip_wahl: { label: "Trinkgeld", kind: "tip" },            // trinkgeldProzent
};

async function findPendingUserTask(piKey) {
  const r = await api("/user-tasks/search", {
    filter: { processInstanceKey: piKey, state: "CREATED" },
  });
  const items = r.items || [];
  if (!items.length) return null;
  const ut = items[0];
  const elementId = ut.elementId;
  const def = USERTASKS[elementId];
  return {
    userTaskKey: String(ut.userTaskKey || ut.key),
    elementId,
    ...(def || { label: elementId, kind: "unknown" }),
  };
}

// ============================================================================
// HTTP-API fuers Frontend
// ============================================================================
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// neue Bestellung starten
app.post("/api/start", async (req, res) => {
  try {
    const bestellId = "tisch-" + Date.now();
    const inst = await api("/process-instances", {
      processDefinitionId: PROCESS_ID,
      variables: { bestellId, tischNr: req.body?.tischNr || 1 },
    });
    const piKey = String(inst.processInstanceKey);
    instances[piKey] = {
      bestellId, tischNr: req.body?.tischNr || 1, personen: null,
      steps: [], done: false,
      order: { items: [], subtotal: 0, zahlungsart: null, tipPercent: null, tipAmount: null, total: null },
      kellner: freshKellnerState(),
      koch: { essen: null, dessert: null },
      essenListe: [], dessertListe: [],
    };
    logStep(piKey, "Bestellung gestartet");
    res.json({ processInstanceKey: piKey, bestellId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Status + ggf. anstehender User Task
app.get("/api/status/:piKey", async (req, res) => {
  const piKey = req.params.piKey;
  const inst = instances[piKey];
  if (!inst) return res.status(404).json({ error: "unbekannte Instanz" });
  let pending = null;
  if (!inst.done) {
    try { pending = await findPendingUserTask(piKey); } catch (e) { /* eventual consistency */ }
  }
  res.json({
    bestellId: inst.bestellId, tischNr: inst.tischNr, personen: inst.personen,
    steps: inst.steps, done: inst.done,
    pending, order: inst.order, kellner: inst.kellner, koch: inst.koch,
  });
});

// Preisliste fuer das Frontend
app.get("/api/prices", (req, res) => res.json(PRICES));

// User Task abschliessen (Werte vom Frontend)
app.post("/api/usertask/complete", async (req, res) => {
  try {
    const { processInstanceKey, userTaskKey, elementId, variables } = req.body;
    const v = variables || {};
    const inst = instances[String(processInstanceKey)];
    const order = inst?.order;
    const extra = {}; // zusaetzliche Variablen, die in den Prozess zurückgeschrieben werden

    // Artikel + Preise erfassen (pro Person, falls mehrere Personen bestellt haben)
    if (order) {
      if (elementId === "Activity_personenzahl") {
        inst.personen = Math.max(1, Math.min(6, Number(v.personen) || 1));
        extra.personen = inst.personen;
      } else if (elementId === "Activity_05poycg") {
        const liste = Array.isArray(v.getraenke) ? v.getraenke : [v.getraenk];
        for (const g of liste) {
          const p = PRICES.getraenke[g] || 0;
          order.items.push({ name: g, price: p });
        }
        extra.getraenk = liste[0]; // einzelne Variable fuer den Prozess (informativ)
      } else if (elementId === "Activity_0oa5gn3") {
        const liste = Array.isArray(v.essen) ? v.essen
          : [{ hauptgericht: v.hauptgericht, vorspeiseGewuenscht: v.vorspeiseGewuenscht, vorspeise: v.vorspeise }];
        let hatVorspeise = false;
        for (const e of liste) {
          const p = PRICES.hauptgerichte[e.hauptgericht] || 0;
          order.items.push({ name: e.hauptgericht, price: p });
          if (e.vorspeiseGewuenscht) {
            hatVorspeise = true;
            const vp = PRICES.vorspeisen[e.vorspeise] || 0;
            order.items.push({ name: e.vorspeise, price: vp });
          }
        }
        if (inst) {
          inst.essenListe = liste.map((e) => ({ hauptgericht: e.hauptgericht, vorspeise: e.vorspeiseGewuenscht ? e.vorspeise : null }));
          inst.kellner.bestellungAufnehmen.ready = true;
        }
        extra.hauptgericht = liste[0].hauptgericht;
        extra.vorspeiseGewuenscht = hatVorspeise; // steuert das Gateway -> "ja" falls mind. 1 Person eine Vorspeise will
        extra.vorspeise = liste.find((e) => e.vorspeiseGewuenscht)?.vorspeise || null;
      } else if (elementId === "Act_k_dessert_wahl") {
        const liste = Array.isArray(v.desserts) ? v.desserts : [{ dessertGewuenscht: v.dessertGewuenscht, dessert: v.dessert }];
        let hatDessert = false;
        const dessertNamen = [];
        for (const d of liste) {
          if (d.dessertGewuenscht) {
            hatDessert = true;
            dessertNamen.push(d.dessert);
            const dp = PRICES.desserts[d.dessert] || 0;
            order.items.push({ name: d.dessert, price: dp });
          }
        }
        if (hatDessert && inst) {
          inst.dessertListe = dessertNamen;
          inst.koch.dessert = { tischNr: inst.tischNr, dessert: dessertNamen.join(", "), fertig: false };
          inst.kellner.dessertServieren.applicable = true;
        }
        extra.dessertGewuenscht = hatDessert; // steuert das Gateway
        extra.dessert = dessertNamen[0] || null;
      } else if (elementId === "Act_k_zahlart") {
        order.zahlungsart = v.zahlungsart;
      } else if (elementId === "Act_k_tip_wahl") {
        const sub = order.items.reduce((s, i) => s + i.price, 0);
        const prozent = v.trinkgeldProzent || 0;
        const tip = round2((sub * prozent) / 100);
        order.subtotal = round2(sub);
        order.tipPercent = prozent;
        order.tipAmount = tip;
        order.total = round2(sub + tip);
        extra.zwischensumme = order.subtotal;
        extra.trinkgeldBetrag = tip;
        extra.gesamtbetrag = order.total;
      }
      order.subtotal = round2(order.items.reduce((s, i) => s + i.price, 0));
    }

    await api(`/user-tasks/${userTaskKey}/completion`, { variables: { ...v, ...extra } });
    logStep(String(processInstanceKey), `Eingabe: ${USERTASKS[elementId]?.label || elementId}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Kellner-Aktion ausloesen (z. B. "Tisch zuweisen", "Hauptgang servieren" ...)
app.post("/api/kellner/action", async (req, res) => {
  try {
    const { processInstanceKey, action } = req.body;
    const inst = instances[String(processInstanceKey)];
    const def = KELLNER_ACTIONS[action];
    const st = inst?.kellner?.[action];
    if (!inst || !def || !st) return res.status(400).json({ error: "unbekannte Aktion" });
    if (!st.ready || st.done) return res.status(409).json({ error: "Aktion aktuell nicht verfügbar" });
    await publishMessage(def.message, inst.bestellId);
    st.done = true; st.ready = false;
    logStep(String(processInstanceKey), "Kellner: " + def.label);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Kueche meldet ein Ticket ("Essen" oder "Dessert") als fertig
app.post("/api/koch/fertig", async (req, res) => {
  try {
    const { processInstanceKey, which } = req.body;
    const inst = instances[String(processInstanceKey)];
    const ticket = inst?.koch?.[which];
    if (!inst || !ticket || ticket.fertig) return res.status(409).json({ error: "kein offenes Ticket" });
    ticket.fertig = true;
    if (which === "essen") {
      if (inst.kellner.vorspeiseServieren.applicable) inst.kellner.vorspeiseServieren.ready = true;
      inst.kellner.hauptgangServieren.ready = true;
      logStep(String(processInstanceKey), "Küche: Essen fertig 🍽️");
    } else if (which === "dessert") {
      inst.kellner.dessertServieren.ready = true;
      logStep(String(processInstanceKey), "Küche: Dessert fertig 🍰");
    }
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================================
// Start: zuerst Verbindung pruefen, dann Worker starten
// ============================================================================
(async () => {
  try {
    const topo = await api("/topology", null, "GET");
    const brokers = topo.brokers?.length ?? "?";
    console.log(`✓ Verbindung zu Camunda ok (${BASE}), Broker: ${brokers}`);
  } catch (err) {
    console.error(`✗ Keine Verbindung zu Camunda unter ${BASE}`);
    console.error(`  Laeuft C8 Run? Stimmt der Port? Details: ${err.message}`);
  }
  SERVICE_TYPES.forEach(startWorker);
  console.log(`✓ ${SERVICE_TYPES.length} Job Worker gestartet`);
  app.listen(PORT, () => console.log(`✓ Webinterface: http://localhost:${PORT}`));
})();
