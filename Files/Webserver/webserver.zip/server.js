// ============================================================================
// Restaurant-Prozess: lokales Backend + Webinterface
// Spricht per REST (v2) mit Camunda 8 Run auf http://localhost:8080/v2
// - Job Worker fuer die 11 Service Tasks (Kunde-Prozess)
// - simuliert Kellner & Kueche durch Publizieren der 7 Nachrichten
// - schliesst die 5 User Tasks mit den Werten aus dem Webinterface ab
// Benoetigt Node.js 18+ (globales fetch)
// ============================================================================

import express from "express";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BASE = process.env.CAMUNDA_REST_ADDRESS || "http://localhost:8080/v2";
const PORT = process.env.PORT || 3000;
const PROCESS_ID = "Process_0t4z7yo"; // Kunde-Prozess (ausfuehrbar)
const MSG_TTL = 300000;               // Nachrichten 5 Min. puffern (in ms)

// Feste Preisliste (CHF)
const PRICES = {
  getraenke: { Wasser: 3.5, Cola: 4.5, Bier: 6.5, Wein: 8.0, Kaffee: 4.0 },
  vorspeisen: { Tagessuppe: 9.5, Blattsalat: 8.5, Bruschetta: 10.5 },
  hauptgerichte: { Pizza: 18.5, Pasta: 17.0, Schnitzel: 24.5, Salat: 14.5 },
  desserts: { Tiramisu: 8.5, Glace: 6.5, Schoggimousse: 7.5 },
};
const round2 = (x) => Math.round(x * 100) / 100;

// ---------------------------------------------------------------------------
// kleiner REST-Helfer
// ---------------------------------------------------------------------------
async function api(pathname, body, method = "POST") {
  const res = await fetch(BASE + pathname, {
    method,
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = text; }
  if (!res.ok) throw new Error(`${method} ${pathname} -> HTTP ${res.status}: ${text}`);
  return data;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------
// In-Memory-Status pro Prozessinstanz (fuer die Live-Anzeige im Frontend)
// ---------------------------------------------------------------------------
const instances = {}; // processInstanceKey -> { bestellId, steps:[], done:false }
function logStep(piKey, text) {
  const inst = instances[piKey];
  if (!inst) return;
  inst.steps.push({ t: new Date().toLocaleTimeString("de-CH"), text });
  console.log(`[${piKey}] ${text}`);
}

// ---------------------------------------------------------------------------
// Nachrichten, die nach Abschluss eines Service Tasks publiziert werden
// (= Kellner/Kueche reagieren und geben den naechsten Catch frei)
// ---------------------------------------------------------------------------
const PUBLISH_AFTER_SERVICE = {
  "restaurant-betreten": ["TischZugewiesen"],
  "platz-nehmen": ["KellnerFragtGetraenk"],
  "bestellung-aufgeben": ["VorspeiseServiert", "HauptgangServiert"],
  "rechnung-verlangen": ["RechnungGebracht"],
};
// Nachrichten nach Abschluss eines User Tasks
const PUBLISH_AFTER_USERTASK = {
  Activity_0oa5gn3: ["KellnerNimmtBestellungAuf"], // Essen aussuchen
  Act_k_dessert_wahl: ["DessertServiert"],          // Dessert waehlen
};

// lesbare Namen fuer das Log
const STEP_LABEL = {
  "restaurant-betreten": "Restaurant betreten",
  "platz-nehmen": "Am Tisch Platz genommen",
  "bestellung-aufgeben": "Bestellung aufgegeben",
  "vorspeise-essen": "Vorspeise gegessen",
  "hauptgang-essen": "Hauptgang gegessen",
  "dessert-essen": "Dessert gegessen",
  "rechnung-verlangen": "Rechnung verlangt",
  "bar-bezahlen": "Bar bezahlt",
  "karte-bezahlen": "Mit Karte bezahlt",
  "trinkgeld-geben": "Trinkgeld gegeben",
  "restaurant-verlassen": "Restaurant verlassen",
};

async function publishMessage(name, correlationKey) {
  await api("/messages/publication", {
    name,
    correlationKey,
    timeToLive: MSG_TTL,
    variables: {},
  });
  console.log(`   -> Nachricht publiziert: ${name} (key=${correlationKey})`);
}

// ---------------------------------------------------------------------------
// Job Worker: aktiviert per Long-Poll Jobs eines Typs und schliesst sie ab
// ---------------------------------------------------------------------------
async function startWorker(type) {
  while (true) {
    try {
      const r = await api("/jobs/activation", {
        type,
        worker: "restaurant-demo",
        timeout: 120000,
        maxJobsToActivate: 10,
        requestTimeout: 4000,
      });
      const jobs = r.jobs || [];
      for (const job of jobs) {
        const jobKey = job.jobKey || job.key;
        const piKey = String(job.processInstanceKey);
        const vars = job.variables || {};
        const bestellId = vars.bestellId;

        await sleep(600); // kleine Verzoegerung fuer realistischen Ablauf
        await api(`/jobs/${jobKey}/completion`, { variables: {} });
        logStep(piKey, STEP_LABEL[type] || type);

        // ggf. Kellner/Kueche-Nachricht(en) publizieren
        for (const msg of PUBLISH_AFTER_SERVICE[type] || []) {
          if (bestellId) await publishMessage(msg, bestellId);
        }
        if (type === "restaurant-verlassen" && instances[piKey]) {
          instances[piKey].done = true;
          logStep(piKey, "Besuch abgeschlossen ✓");
        }
      }
    } catch (err) {
      // bei Verbindungsproblemen kurz warten, dann erneut versuchen
      console.error(`Worker ${type}: ${err.message}`);
      await sleep(2000);
    }
  }
}

const SERVICE_TYPES = Object.keys(STEP_LABEL);

// ---------------------------------------------------------------------------
// User Tasks: Definition fuer das Frontend (Label + Formular-Art)
// ---------------------------------------------------------------------------
const USERTASKS = {
  Activity_05poycg: {
    label: "Getränk auswählen",
    kind: "select",
    field: "getraenk",
    options: ["Wasser", "Cola", "Bier", "Wein", "Kaffee"],
  },
  Activity_0oa5gn3: { label: "Essen auswählen", kind: "essen" }, // hauptgericht + vorspeiseGewuenscht
  Act_k_dessert_wahl: { label: "Dessert?", kind: "dessert" },     // dessertGewuenscht (+ dessert)
  Act_k_zahlart: { label: "Zahlungsart", kind: "zahlung" },       // zahlungsart
  Act_k_tip_wahl: { label: "Trinkgeld", kind: "tip" },            // trinkgeldProzent
};

async function findPendingUserTask(piKey) {
  const r = await api("/user-tasks/search", {
    filter: { processInstanceKey: piKey, state: "CREATED" },
  });
  const items = r.items || [];
  if (!items.length) return null;
  const ut = items[0];
  const elementId = ut.elementId;
  const def = USERTASKS[elementId];
  return {
    userTaskKey: String(ut.userTaskKey || ut.key),
    elementId,
    ...(def || { label: elementId, kind: "unknown" }),
  };
}

// ============================================================================
// HTTP-API fuers Frontend
// ============================================================================
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// neue Bestellung starten
app.post("/api/start", async (req, res) => {
  try {
    const bestellId = "tisch-" + Date.now();
    const inst = await api("/process-instances", {
      processDefinitionId: PROCESS_ID,
      variables: { bestellId, tischNr: req.body?.tischNr || 1 },
    });
    const piKey = String(inst.processInstanceKey);
    instances[piKey] = {
      bestellId, steps: [], done: false,
      order: { items: [], subtotal: 0, zahlungsart: null, tipPercent: null, tipAmount: null, total: null },
    };
    logStep(piKey, "Bestellung gestartet");
    res.json({ processInstanceKey: piKey, bestellId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Status + ggf. anstehender User Task
app.get("/api/status/:piKey", async (req, res) => {
  const piKey = req.params.piKey;
  const inst = instances[piKey];
  if (!inst) return res.status(404).json({ error: "unbekannte Instanz" });
  let pending = null;
  if (!inst.done) {
    try { pending = await findPendingUserTask(piKey); } catch (e) { /* eventual consistency */ }
  }
  res.json({ bestellId: inst.bestellId, steps: inst.steps, done: inst.done, pending, order: inst.order });
});

// Preisliste fuer das Frontend
app.get("/api/prices", (req, res) => res.json(PRICES));

// User Task abschliessen (Werte vom Frontend)
app.post("/api/usertask/complete", async (req, res) => {
  try {
    const { processInstanceKey, userTaskKey, elementId, variables } = req.body;
    const v = variables || {};
    const inst = instances[String(processInstanceKey)];
    const order = inst?.order;
    const extra = {}; // zusaetzliche Variablen, die in den Prozess zurückgeschrieben werden

    // Artikel + Preise erfassen
    if (order) {
      if (elementId === "Activity_05poycg") {
        const p = PRICES.getraenke[v.getraenk] || 0;
        order.items.push({ name: v.getraenk, price: p });
        extra.getraenkPreis = p;
      } else if (elementId === "Activity_0oa5gn3") {
        const p = PRICES.hauptgerichte[v.hauptgericht] || 0;
        order.items.push({ name: v.hauptgericht, price: p });
        extra.hauptgerichtPreis = p;
        if (v.vorspeiseGewuenscht) {
          const vp = PRICES.vorspeisen[v.vorspeise] || 0;
          order.items.push({ name: v.vorspeise, price: vp });
          extra.vorspeisePreis = vp;
        }
      } else if (elementId === "Act_k_dessert_wahl") {
        if (v.dessertGewuenscht) {
          const dp = PRICES.desserts[v.dessert] || 0;
          order.items.push({ name: v.dessert, price: dp });
          extra.dessertPreis = dp;
        }
      } else if (elementId === "Act_k_zahlart") {
        order.zahlungsart = v.zahlungsart;
      } else if (elementId === "Act_k_tip_wahl") {
        const sub = order.items.reduce((s, i) => s + i.price, 0);
        const prozent = v.trinkgeldProzent || 0;
        const tip = round2((sub * prozent) / 100);
        order.subtotal = round2(sub);
        order.tipPercent = prozent;
        order.tipAmount = tip;
        order.total = round2(sub + tip);
        extra.zwischensumme = order.subtotal;
        extra.trinkgeldBetrag = tip;
        extra.gesamtbetrag = order.total;
      }
      order.subtotal = round2(order.items.reduce((s, i) => s + i.price, 0));
    }

    await api(`/user-tasks/${userTaskKey}/completion`, { variables: { ...v, ...extra } });
    logStep(String(processInstanceKey), `Eingabe: ${USERTASKS[elementId]?.label || elementId}`);
    for (const msg of PUBLISH_AFTER_USERTASK[elementId] || []) {
      if (inst) await publishMessage(msg, inst.bestellId);
    }
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================================
// Start: zuerst Verbindung pruefen, dann Worker starten
// ============================================================================
(async () => {
  try {
    const topo = await api("/topology", null, "GET");
    const brokers = topo.brokers?.length ?? "?";
    console.log(`✓ Verbindung zu Camunda ok (${BASE}), Broker: ${brokers}`);
  } catch (err) {
    console.error(`✗ Keine Verbindung zu Camunda unter ${BASE}`);
    console.error(`  Laeuft C8 Run? Stimmt der Port? Details: ${err.message}`);
  }
  SERVICE_TYPES.forEach(startWorker);
  console.log(`✓ ${SERVICE_TYPES.length} Job Worker gestartet`);
  app.listen(PORT, () => console.log(`✓ Webinterface: http://localhost:${PORT}`));
})();
